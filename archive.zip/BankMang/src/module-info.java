/**
 * 
 */
/**
 * 
 */
module BankMang {
	requires java.sql;
	requires java.base;
	requires mysql.connector.j;
}