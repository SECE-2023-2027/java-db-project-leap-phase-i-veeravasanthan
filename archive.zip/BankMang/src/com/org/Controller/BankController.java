package com.org.Controller;

import java.sql.SQLException;
import java.util.Scanner;

import com.org.model.Bank;
import com.org.service.Service;
import com.org.service.ServiceImpl;

public class BankController {
	public static void main(String[] args)  {
	Service sv=new ServiceImpl();	
	Bank n=new Bank();
	try {
		Bank.db_Connect();
		
		boolean exe=true;
		while(exe) {
		System.out.println("Connection sucessful");
		System.out.println("1 .Create Account");
		System.out.println("2 .View Account");
		System.out.println("3 .update Account info");
		System.out.println("4 .Withdraw");
		System.out.println("5 .Deposit");
		System.out.println("6 .Transcation Amount");
		System.out.println("7 .View Transaction");
		System.out.println("8 .Exit");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a option:");
		int input=sc.nextInt();
		switch(input)
		{
		case 1:
			System.out.println("1");
			sv.createaccount();
			break;
		case 2:
			sv.viewaccount();
			System.out.println("2");
			break;
		case 3:
			sv.updateaccount();
			System.out.println("3");
			break;
		case 4:
			sv.withdraw();
			System.out.println("4");
			break;
		case 5:
			sv.deposit();
			System.out.println("5");
			break;
		case 6:
			sv.amount_trans();
			System.out.println("6");
			break;
		case 7:
			sv.viewtrans();
			System.out.println("7");
			break;
		case 8:
			sv.exit();
			System.out.println("8");
			break;
		default:
			System.out.println("Invalid Arguement");
			break;
		}
		}
	}catch(SQLException e){
		e.printStackTrace();
	}
	}
}
