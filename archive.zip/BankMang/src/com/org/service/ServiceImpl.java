package com.org.service;

import java.sql.Connection;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.org.model.Bank;

public class ServiceImpl implements Service {
 private static Scanner sc=new Scanner(System.in);
	@Override
	public void createaccount() {
		// TODO Auto-generated method stub
		   Connection con = null;
		try {
			con = Bank.db_Connect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        try {
	            System.out.println("Enter Customer ID:");
	            int c_id = sc.nextInt();
	            System.out.println("Enter account type (1. Savings / 2. Current):");
	            int id = sc.nextInt();
	            String type = (id == 1) ? "savings" : "current";

	            System.out.println("Enter initial amount:");
	            double balance = sc.nextDouble();

	            System.out.println("Enter your address:");
	            String address = sc.next();

	            System.out.println("Enter your mobile number:");
	            String mobile = sc.next();

	            String sql = "INSERT INTO account (customer_id, account_type, balance, created_at, address, mobile) VALUES (?, ?, ?, NOW(), ?, ?)";
	            PreparedStatement pstmt = con.prepareStatement(sql);
	            pstmt.setInt(1, c_id);
	            pstmt.setString(2, type);
	            pstmt.setDouble(3, balance);
	            pstmt.setString(4, address);
	            pstmt.setString(5, mobile);
              
	            int rowsInserted = pstmt.executeUpdate();
	            if (rowsInserted > 0) {
	                System.out.println("Account created successfully.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	@Override
	public void viewaccount() {
		 try  {
		// TODO Auto-generated method stub
		System.out.println("Enter account ID to view details: ");
	    int acc_id = sc.nextInt();
	    Connection con = Bank.db_Connect();
	    
	    String sql = "SELECT * FROM account WHERE account_id = ?";
	    PreparedStatement pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1, acc_id);
	        var rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            System.out.println("Account ID: " + rs.getInt("acc_id"));
	            System.out.println("Customer ID: " + rs.getInt("customer_id"));
	            System.out.println("Account Type: " + rs.getString("acc_type"));
	            System.out.println("Balance: " + rs.getDouble("balance"));
	            System.out.println("Address: " + rs.getString("address"));
	            System.out.println("Mobile: " + rs.getString("mobile"));
	        } else {
	            System.out.println("Account not found!");
	        }
	    }catch(Exception e)
		 {
	    	System.out.println(e);
		 }

	}

	@Override
	public void updateaccount() {
		// TODO Auto-generated method stub
		System.out.println("Enter account ID to update: ");
	    int acc_id = sc.nextInt();
	    System.out.println("Enter new address: ");
	    String newAddress = sc.next();
	    System.out.println("Enter new mobile number: ");
	    String newMobile = sc.next();
	    Connection con = null;
		try {
			con = Bank.db_Connect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    String sql = "UPDATE account SET address = ?, mobile = ? WHERE account_id = ?";
	    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
	        pstmt.setString(1, newAddress);
	        pstmt.setString(2, newMobile);
	        pstmt.setInt(3, acc_id);
	        int rowsUpdated = pstmt.executeUpdate();  
	        if (rowsUpdated > 0) {
	            System.out.println("Account updated successfully!");
	        } else {
	            System.out.println("Account not found.");
	        }}
	        catch(Exception e){
	        	System.out.println(e);
	        }
	    } 
	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("Enter account ID to withdraw from: ");
	    int acc_id = sc.nextInt();
	    
	    System.out.println("Enter amount to withdraw: ");
	    double amount = sc.nextDouble();
	    
	    Connection con = null;
		try {
			con = Bank.db_Connect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    String fetchBalanceSql = "SELECT balance FROM account WHERE account_id = ?";
	    try (PreparedStatement pstmt = con.prepareStatement(fetchBalanceSql)) {
	        pstmt.setInt(1, acc_id);
	        var rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            double balance = rs.getDouble("balance");
	            if (balance >= amount) {
	                String updateBalanceSql = "UPDATE account SET balance = ? WHERE account_id = ?";
	                try (PreparedStatement updatePstmt = con.prepareStatement(updateBalanceSql)) {
	                    updatePstmt.setDouble(1, balance - amount);
	                    updatePstmt.setInt(2, acc_id);
	                    updatePstmt.executeUpdate();
	                    
	                    System.out.println("Withdrawal successful. New balance: " + (balance - amount));
	                }}
	            
	             else {
	                System.out.println("Insufficient balance.");
	            }
	        } else {
	            System.out.println("Account not found.");
	        }
	    } catch (Exception e) {
	        System.out.println("Error during withdrawal: " + e.getMessage());
	    }
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Enter account ID to deposit into: ");
	    int acc_id = sc.nextInt();
	    
	    System.out.println("Enter amount to deposit: ");
	    double amount = sc.nextDouble();
	    
	    Connection con = null;
		try {
			con = Bank.db_Connect();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
	    String fetchBalanceSql = "SELECT balance FROM acc WHERE acc_id = ?";
	    try (PreparedStatement pstmt = con.prepareStatement(fetchBalanceSql)) {
	        pstmt.setInt(1, acc_id);
	        var rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            double balance = rs.getDouble("balance");
	            String updateBalanceSql = "UPDATE acc SET balance = ? WHERE acc_id = ?";
	            try (PreparedStatement updatePstmt = con.prepareStatement(updateBalanceSql)) {
	                updatePstmt.setDouble(1, balance + amount);
	                updatePstmt.setInt(2, acc_id);
	                updatePstmt.executeUpdate();
	                
	                System.out.println("Deposit successful. New balance: " + (balance + amount));
	            }
	        } else {
	            System.out.println("Account not found.");
	        }
	    } catch (Exception e) {
	        System.out.println("Error during deposit: " + e.getMessage());
	    }
		}

	@Override
	public void amount_trans() {
		// TODO Auto-generated method stub
		System.out.println("Enter source account ID: ");
        int fromAcc = sc.nextInt();

        System.out.println("Enter target account ID: ");
        int toAcc = sc.nextInt();

        System.out.println("Enter amount to transfer: ");
        double amount = sc.nextDouble();

        Connection con = null;
        try {
            con = Bank.db_Connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Check if the source account has enough balance
        String fetchBalanceSql = "SELECT balance FROM acc WHERE acc_id = ?";
        try (PreparedStatement pstmt = con.prepareStatement(fetchBalanceSql)) {
            pstmt.setInt(1, fromAcc);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance >= amount) {
                    // Deduct from source account
                    String updateFromSql = "UPDATE acc SET balance = ? WHERE acc_id = ?";
                    try (PreparedStatement updateFromPstmt = con.prepareStatement(updateFromSql)) {
                        updateFromPstmt.setDouble(1, balance - amount);
                        updateFromPstmt.setInt(2, fromAcc);
                        updateFromPstmt.executeUpdate();
                    }

                    // Add to target account
                    String fetchTargetBalanceSql = "SELECT balance FROM acc WHERE acc_id = ?";
                    try (PreparedStatement fetchTargetPstmt = con.prepareStatement(fetchTargetBalanceSql)) {
                        fetchTargetPstmt.setInt(1, toAcc);
                        ResultSet targetRs = fetchTargetPstmt.executeQuery();

                        if (targetRs.next()) {
                            double targetBalance = targetRs.getDouble("balance");
                            String updateTargetSql = "UPDATE acc SET balance = ? WHERE acc_id = ?";
                            try (PreparedStatement updateTargetPstmt = con.prepareStatement(updateTargetSql)) {
                                updateTargetPstmt.setDouble(1, targetBalance + amount);
                                updateTargetPstmt.setInt(2, toAcc);
                                updateTargetPstmt.executeUpdate();
                                
                                // Log the transaction
                                String transactionSql = "INSERT INTO transaction (acc_id, transaction_type, amount) VALUES (?, ?, ?)";
                                try (PreparedStatement transactionPstmt = con.prepareStatement(transactionSql)) {
                                    transactionPstmt.setInt(1, fromAcc);
                                    transactionPstmt.setString(2, "debit");
                                    transactionPstmt.setDouble(3, amount);
                                    transactionPstmt.executeUpdate();
                                    
                                    transactionPstmt.setInt(1, toAcc);
                                    transactionPstmt.setString(2, "credit");
                                    transactionPstmt.setDouble(3, amount);
                                    transactionPstmt.executeUpdate();
                                }

                                System.out.println("Transfer successful.");
                            }
                        } else {
                            System.out.println("Target account not found.");
                        }
                    }
                } else {
                    System.out.println("Insufficient balance.");
                }
            } else {
                System.out.println("Source account not found.");
            }
        } catch (Exception e) {
            System.out.println("Error during transfer: " + e.getMessage());
        }
	}

	@Override
	public void viewtrans() {
		// TODO Auto-generated method stub
		System.out.println("Enter account ID to view transactions: ");
        int acc_id = sc.nextInt();
        
        Connection con = null;
        try {
            con = Bank.db_Connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql = "SELECT * FROM transaction WHERE acc_id = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, acc_id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Account ID: " + rs.getInt("acc_id"));
                System.out.println("Transaction Type: " + rs.getString("transaction_type"));
                System.out.println("Amount: " + rs.getDouble("amount"));
                System.out.println("Transaction Date: " + rs.getTimestamp("transaction_date"));
            } else {
                System.out.println("No transactions found.");
            }
        } catch (Exception e) {
            System.out.println("Error retrieving transactions: " + e.getMessage());
        }
    }
	public void exit()
	{
		 System.out.println("Exited");
	}
}
